<?php


namespace App\Helpers;


class TreeHelper
{

    private $maxChildCount;
    public function __construct($maxChildCount  = 4)
    {
        $this->maxChildCount = $maxChildCount;
    }


    function findEmptyNode($userId){

    }
}
