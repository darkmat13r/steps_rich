<?php
namespace LaravelFeed\Contracts;

interface FeedContract
{

}
