<?php


namespace LaravelFeed\Contracts;


interface FeedImageContract
{

}
