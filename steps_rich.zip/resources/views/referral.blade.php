<x-app-layout>
   <h1>Please wait...</h1>
</x-app-layout>

<script>
    $(()=>{
        window.location.href = "https://play.google.com/store/apps/details?id=com.darkmat13r.ugoku&referrer={{$code}}"
    })
</script>


