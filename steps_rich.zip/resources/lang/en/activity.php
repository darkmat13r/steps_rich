<?php
return [
    'errors' => [
        'invalid_activity' => 'Invalid activity :name'
    ]
];
