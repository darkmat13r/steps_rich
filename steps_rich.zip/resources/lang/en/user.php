<?php

return [
    'errors' => [
        'invalid_activity_level' => 'Invalid activity level',
        'user_not_found' => 'User not found',
        'not_eligible' => 'Sorry, You are not eligible',
        'not_approved' => 'User not approved',
    ]
];
