<?php $__env->startPush('title','Feeds'); ?>
<?php $__env->startPush('headerscript'); ?>
    <link href="<?php echo e(asset('admin/plugins/custom/datatables/datatables.bundled1cf.css?v=7.1.6')); ?>" rel="stylesheet"
          type="text/css"/>
    <style>
        .table {
            display: inline-table;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
        <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5">Feeds</h5>
                    <!--end::Page Title-->
                </div>
                <!--end::Page Heading-->
            </div>
            <div class="d-flex align-items-center">
                <!--begin::Actions-->
                <a href="<?php echo e(route('feed.create')); ?>" class="btn btn-light-primary font-weight-bolder">
                    <i class="fas fa-plus"></i>
                    ADD
                </a>
                <!--end::Actions-->
            </div>
            <!--end::Info-->
        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Card-->
            <div class="card card-custom gutter-b">
                <div class="card-body">
                    <!--begin: Datatable-->
                    <div class="row">
                        <div class="col-sm-12 col-12 table-responsive">
                            <table class="table table-responsive datatables" id="datatables">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User</th>
                                    <th>Image</th>
                                    <th>Content</th>
                                    <th>Amount</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!--end: Datatable-->
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerscript'); ?>
    <script src="<?php echo e(asset('admin/plugins/custom/datatables/datatables.bundled1cf.js?v=7.1.6')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/pages/crud/datatables/basic/basicd1cf.js?v=7.1.6')); ?>"></script>
    <script src=".<?php echo e(asset('admin/js/pages/features/miscellaneous/sweetalert2d1cf.js?v=7.1.6')); ?>"></script>
    <script>
        $(function () {
            $('#datatables').DataTable({
                processing: true,
                serverSide: true,
                stateSave: true,
                ajax: {
                    url: '<?php echo e(url('admin/feed/getData')); ?>',
                },
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', searchable: false},
                    {data: 'user_name', name: 'user_name'},
                    {data: 'url', name: 'url'},
                    {data: 'content', name: 'content'},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                ]
            });
        })
    </script>

    <script>
        function deleteIt(id) {
            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel!",
                reverseButtons: true
            }).then(function (result) {
                if (result.value) {
                    $.ajax({
                        url: '<?php echo e(url('admin/feed')); ?>/' + id,
                        type: 'delete',
                        dataType: "JSON",
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>"
                        },
                        success: function () {
                            location.reload()
                        }
                    });
                    swal.fire("Deleted!", "Data has been deleted!", "success");
                } else if (result.dismiss === "cancel") {
                    swal.fire("Cancelled", "Data is safe :)", "error");
                }
            });
        }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\htdocs\steps_rich\resources\views/admin/feed/index.blade.php ENDPATH**/ ?>