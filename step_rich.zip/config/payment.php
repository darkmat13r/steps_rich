<?php

return [
    'provider' => env('PAYMENT_PROVIDER', 'paypal')
];
