<?php


namespace LaravelFeed\Contracts;


interface FeedLike
{

}
