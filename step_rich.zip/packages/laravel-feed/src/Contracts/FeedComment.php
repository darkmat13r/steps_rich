<?php


namespace LaravelFeed\Contracts;


interface FeedComment
{

}
