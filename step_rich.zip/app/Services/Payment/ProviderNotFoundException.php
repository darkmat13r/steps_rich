<?php


namespace App\Services\Payment;


class ProviderNotFoundException extends \Exception
{

}
