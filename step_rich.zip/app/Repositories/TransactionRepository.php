<?php


namespace App\Repositories;


use App\Models\User;

class TransactionRepository
{


}
